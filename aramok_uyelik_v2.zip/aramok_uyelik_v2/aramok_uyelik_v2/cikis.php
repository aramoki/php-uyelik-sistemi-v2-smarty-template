<?php

require_once('Smarty.class.php');
$smarty = new Smarty();
$smarty->template_dir = 'template/simple';
$smarty->compile_dir  = 'templates_c';
$smarty->config_dir   = 'configs';
$smarty->cache_dir    = 'cache';

setcookie("uyeid", "", time() - 7200);
setcookie("uyead", "", time() - 7200);
setcookie("uyemail", "", time() - 7200);

$smarty->assign('yonlen','1'); 


$smarty->display('cikis.tpl');
?>