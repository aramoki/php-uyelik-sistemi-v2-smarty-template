<?php
include"ust.php";
$dosya =$_FILES["dosya"]["name"];



if ((($_FILES["dosya"]["type"] == "image/gif")
|| ($_FILES["dosya"]["type"] == "image/jpeg")
|| ($_FILES["dosya"]["type"] == "image/png")
|| ($_FILES["dosya"]["type"] == "image/pjpeg"))
&& ($_FILES["dosya"]["size"] < 9999999999999999999999999999999999999))
  {
  if ($_FILES["dosya"]["error"] > 0)
    {
  $smarty->assign('bildir',"Return Code: " . $_FILES["dosya"]["error"] . "<br />");
    }
  else
    {

    if (file_exists("images/avatar/" . $_FILES["dosya"]["name"]))
      {
  $smarty->assign('bildir',"".$_FILES["dosya"]["name"] ." adinda baska bir dosya var</div>");
	 

      }
    else
      {
      
	  
	  if($_FILES["dosya"]["type"] == "image/png"){
move_uploaded_file($_FILES["dosya"]["tmp_name"], "images/avatar/" . $_FILES["dosya"]["name"]);
	  }else{
move_uploaded_file($_FILES["dosya"]["tmp_name"], "images/avatar/" . $_FILES["dosya"]["name"]);}
	  
  $smarty->assign('bildir',"Yuklendi: " . "<img src='images/avatar/" . $_FILES["dosya"]["name"]."'");
	 
	 
	 unlink("images/avatar/$_POST[uav]");
	 $sql=mysql_query("UPDATE uyeler SET avatar='$dosya' WHERE uye_id = '$_POST[uid]'");
	 
      }
    }
  }
else
  {
  $smarty->assign('bildir',"Uyumsuz dosya");

  }




  

$smarty->display('avatar.tpl');
?>