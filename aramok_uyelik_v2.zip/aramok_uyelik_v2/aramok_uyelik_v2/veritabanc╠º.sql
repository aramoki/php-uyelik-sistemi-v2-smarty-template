-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Sunucu: localhost
-- Çıktı Tarihi: Nisan 05, 2011 at 07:29 AM
-- Server sürümü: 5.0.18
-- PHP Sürümü: 5.1.2
-- 
-- Veritabanı: `uyelik2`
-- 

-- --------------------------------------------------------

-- 
-- Tablo yapısı : `uyeler`
-- 

CREATE TABLE `uyeler` (
  `uye_id` int(11) NOT NULL auto_increment,
  `uye_ad` text NOT NULL,
  `uye_sifre` varchar(48) NOT NULL,
  `uye_mail` varchar(50) NOT NULL,
  `uye_kayit` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `uye_bolge` text NOT NULL,
  `uye_web` text NOT NULL,
  `uye_meslek` text NOT NULL,
  `uye_bilgi` text NOT NULL,
  `avatar` text NOT NULL,
  `ctrl` text NOT NULL,
  `aktif` int(11) NOT NULL,
  `admin` int(11) NOT NULL,
  `ban` int(11) NOT NULL,
  `avatar` text NOT NULL,
  `login` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`uye_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Tablo döküm verisi `uyeler`
-- 

INSERT INTO `uyeler` VALUES (1, 'aramok', '85136c79cbf9fe36bb9d05d0639c70c265c18d37', 'admin@localhost', '0000-00-00 00:00:00', 'bolu', 'www.aramok.com', 'programci', 'merhaba ben aramok web programcisiyim vs  vs  vs ','', 'onaykodu', 1, 0, 0, '', '0000-00-00 00:00:00');
