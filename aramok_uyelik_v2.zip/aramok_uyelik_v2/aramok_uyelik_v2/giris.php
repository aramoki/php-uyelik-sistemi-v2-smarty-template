<?php

require "baglanti.php";
require_once('Smarty.class.php');
$smarty = new Smarty();
$smarty->template_dir = 'template/simple';
$smarty->compile_dir  = 'templates_c';
$smarty->config_dir   = 'configs';
$smarty->cache_dir    = 'cache';


if($_POST['id'] == "" || $_POST['key'] == "") {
$smarty->assign('bildir',"L�tfen T�m Alanlar� Doldurun");
}else{


$uyead = strip_tags(mysql_real_escape_string($_POST['id']));
$sifre = strip_tags(mysql_real_escape_string($_POST['key']));
$sifre = sha1($sifre);
$sql = mysql_query("select * from uyeler where  uye_ad='$uyead' and uye_sifre='$sifre'   ");
$uyevarmi = mysql_num_rows($sql);
if($uyevarmi == 0) {
$smarty->assign('bildir',"�yelik bilgileri bulunamad�, tekrar deneyin");
} else {



$uyebilgi = mysql_fetch_array($sql);
if($uyebilgi['ban']==1){
$smarty->assign('banc','1');
}else{
if($uyebilgi['aktif']==1){
$expire=time()+60*60*24*30;
setcookie("uyeid", "$uyebilgi[uye_id]", $expire);
setcookie("uyead", "$uyebilgi[uye_ad]", $expire);
setcookie("uyemail", "$uyebilgi[uye_mail]", $expire);

$loginreg=mysql_query("UPDATE uyeler SET login = NOW()  WHERE uye_id = '$uyebilgi[uye_id]'");
$smarty->assign('yonlen','1');
}else{
$smarty->assign('aktifc','1');
}
}

 // javascript y�nlendirme kodu
} // if($uyevarmi == 0) kontrol� biti�i
}//textbox post verileri i�erik kontrol�

$smarty->display('giris.tpl');

?>



