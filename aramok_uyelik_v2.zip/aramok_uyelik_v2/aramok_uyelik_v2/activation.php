<?php
include"ust.php";

if(isset($_POST['kod'])){

$onaycek=mysql_query("UPDATE uyeler SET aktif ='1' where  ctrl='$_POST[kod]' and uye_ad ='$_POST[ad]'");
$smarty->assign('bildir',"aktivasyon tamamlandi login olabilirsiniz");
$smarty->assign('kod',1);
}else{
$smarty->assign('kod',0);
}

$smarty->display('activation.tpl'); 