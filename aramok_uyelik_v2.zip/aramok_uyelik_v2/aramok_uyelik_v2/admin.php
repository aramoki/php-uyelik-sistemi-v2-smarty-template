<?php
include"ust.php";



$smarty->display('admin.tpl');

if($_GET['sayfa'] == "uyeler"){
include"adminlib/uye.sayfa.php";}

elseif($_GET['duzenle'] == "uye"){
include"adminlib/uye.duzenle.php";}

elseif($_GET['duzenleok'] == "uye"){
include"adminlib/uye.duzenleok.php";}

elseif($_GET['sil'] == "uye"){
include"adminlib/uye.sil.php";}

elseif($_GET['ekle'] == "uye"){
include"adminlib/uye.ekle.php";}

else{ include"adminlib/uye.sayfa.php"; }



