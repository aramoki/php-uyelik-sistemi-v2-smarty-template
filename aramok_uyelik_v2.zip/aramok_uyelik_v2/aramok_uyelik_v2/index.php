<?php
require "ust.php";




//Display the Smarty template 
$smarty->display('index.tpl'); 
?>