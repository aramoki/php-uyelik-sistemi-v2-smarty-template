<?php

if($_POST['isim']!=""){
if($_POST['sifre']!=""){
if($_POST['mail']!=""){



$uyesorgu=mysql_query("Select uye_ad from uyeler where uye_ad='".$_POST['isim']."'");
$mailsorgu = mysql_query("SELECT uye_mail FROM uyeler WHERE uye_mail='".$_POST['mail']."'");  
$uyesayi=mysql_num_rows($uyesorgu); 
$mailsayi=mysql_num_rows($mailsorgu); 
if (!($uyesayi>0)){
if (!($mailsayi>0)){



$pw=sha1($_POST['sifre']);


$uyeekle = "INSERT INTO uyeler (uye_id,uye_ad, uye_sifre, uye_mail,uye_kayit) 
VALUES ('','".$_POST['isim']."', '".$pw."', '".$_POST['mail']."',now() )";

if (!mysql_query($uyeekle,$bag))
  {
  die('Err�r: ' . mysql_error());
  }else{
  echo"
  <b>kullanici ad:</b>$_POST[isim]<br>
  <b>Sifre:</b>$_POST[sifre]<br>
  <b>mail :</b>$_POST[mail]<br>
   ";
  
  }
  
  
  
 
 
}else{echo"sectigin mail var";}
}else{echo"sectigin kullanici adi var";}
}else{echo"mail adresi girmediniz";}
}else{echo"sifre girmediniz";}
}else{echo"�sim girmediniz";}




