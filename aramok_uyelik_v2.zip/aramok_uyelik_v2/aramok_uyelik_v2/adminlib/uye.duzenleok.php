<?php

$sifre1=$_POST['sifre1'];
$sifre2=$_POST['sifre2'];

$msifre=sha1($sifre1); 

if(($sifre1=="")and($sifre2=="")){



$sql=mysql_query("UPDATE uyeler SET uye_bolge='$_POST[bolge]', uye_mail='$_POST[mail]' ,uye_web='$_POST[web]',uye_ad='$_POST[ad]' ,uye_meslek='$_POST[meslek]',uye_bilgi='$_POST[bilgi]'
WHERE uye_id = '$_POST[kid]'");

if (!mysql_query($sql,$con))
  {
  die('Duzenlendi');
  }

}else{

if($sifre1==$sifre2){ 


$sql2=mysql_query("UPDATE uyeler SET uye_sifre='$msifre' , uye_bolge='$_POST[bolge]', uye_mail='$_POST[mail]' ,uye_web='$_POST[web]',uye_ad='$_POST[ad]' ,uye_meslek='$_POST[meslek]',uye_bilgi='$_POST[bilgi]'
WHERE uye_id = '$_POST[kid]'");

if (!mysql_query($sql2,$con))
  {
  die('sifrede Duzenlendi');
  }

}else{
echo"sifreler uyusmuyor";}
}



  


