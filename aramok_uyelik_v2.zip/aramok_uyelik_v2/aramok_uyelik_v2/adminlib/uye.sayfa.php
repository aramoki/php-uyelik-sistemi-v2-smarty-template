<?php

/////sayfa bolme sistemi verileri
if($_GET['cid']==""){
$_GET['cid']=0;}

$limit=50; 
if($_GET['s']==""){
$_GET['s']=1;}
$x=$_GET['s']-1;
$son = ($x)*$limit;
$ar=$_GET['s']+1;
$b=$_GET['s']-1;

$renkdegistir = "<font style='background-color:#FFFF00;'  >".$_POST['ara']."</font>";
$r=$_POST['var'];
$c=$r+1;
$d=$r-1;

if(isset($_POST['arti'])){
$sqla=mysql_query("UPDATE uyeler SET admin='$c' WHERE uye_id = '$_POST[arti]'");
//echo"<script>location.href='admin.php?sayfa=uyeler';</script>";
}elseif(isset($_POST['eksi'])){
$sqla=mysql_query("UPDATE uyeler SET admin='$d' WHERE uye_id = '$_POST[eksi]'");
//echo"<script>location.href='admin.php?sayfa=uyeler';</script>";
}



if(isset($_POST['ban'])){
if($_POST['bi'] >0){$bi=0;}else{$bi=1;}
$bana=mysql_query("UPDATE uyeler SET ban='$bi' WHERE uye_id = '$_POST[ban]'");
//echo"<script>location.href='admin.php?sayfa=uyeler ';</script>";
}



echo"<table cellspacing='0' cellspadding='0' width='100%' class='admintable' align='left' >";
 echo"<tr><td colspan='8' width='1%' ><form action='?sayfa=uyeler&sirala=ara' method='post' class='formx'>
  <input type='text' name='ara' value='$_POST[ara]' > <input type='submit' value='ara' >

    sirala:<select name='sirala'>
  <option value='uye_ad' selected>isim</option>
  <option value='admin'>rutbe</option>
  <option value='uye_kayit'>tarih</option>
  <option value='login'>en son giri�</option>
  <option value='uye_mail'>mail</option>
  </select><select name='siralat'>
  <option value='desc' selected>A-Z</option>
  <option value=''>Z-A</option>
  </select>
  -
  sirala:<select name='admin'>
  <option value='0' >na-user</option>
  <option value='1' selected>user</option>
  <option value='2'>Moderator</option>
  <option value='3'>Editor</option>
  <option value='4'>CoAdmin</option>
  <option value='5'>Admin</option>
  </select>
  </form></td></tr>";

if(isset($_GET['sirala'])){
if(isset($_POST['ara'])){
$uyeler = mysql_query("SELECT * FROM uyeler  where (uye_ad LIKE '%$_POST[ara]%' || uye_mail LIKE '%$_POST[ara]%' ) order by $_POST[sirala] $_POST[siralat] LIMIT $son,$limit");
$says = mysql_num_rows($uyeler);

//////////////
 echo"<tr><td colspan='8' width='1%' >";
 if(($says==0)){
echo"Arad���n�z kelime bulunamad�";
}else{
echo"".$_GET['ara']." �zerine Arama Sonu�lar�. $_POST[sirala] g�re s�ralama";
}
echo"</td></tr>";
////////////
}else{
$uyeler = mysql_query("SELECT * FROM uyeler order by $_GET[sirala] LIMIT $son,$limit"); 

//////////
echo"<tr>
<td><a href='?sayfa=uyeler&sirala=uye_ad'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=uye_ad desc'><img src='images/admin/yukar.bmp'></a></td>
<td><a href='?sayfa=uyeler&sirala=admin'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=admin desc'><img src='images/admin/yukar.bmp'></a></td>
<td><a href='?sayfa=uyeler&sirala=uye_kayit'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=uye_kayit desc'><img src='images/admin/yukar.bmp'></a></td>
<td><a href='?sayfa=uyeler&sirala=login'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=login desc'><img src='images/admin/yukar.bmp'></a></td>
<td><a href='?sayfa=uyeler&sirala=uye_mail'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=uye_mail desc'><img src='images/admin/yukar.bmp'></a></td>

<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>";
//////////
}

}else{
if(isset($_POST['ara'])){
$uyeler = mysql_query("SELECT * FROM uyeler  where (uye_ad LIKE '%$_POST[ara]%' || uye_mail LIKE '%$_POST[ara]%') order by uye_id LIMIT $son,$limit");
$says = mysql_num_rows($uyeler);
//////////////
 echo"<tr><td colspan='8' width='1%' >";
 if(($says==0)){
echo"Arad���n�z kelime bulunamad�";
}else{
echo"".$_GET['ara']." �zerine Arama Sonu�lar�. Toplam <b>$says</b> sonu� bulundu. $_POST[sirala] g�re s�ralama";
}
echo"</td></tr>";
/////////////
}else{
$uyeler = mysql_query("SELECT * FROM uyeler order by uye_id LIMIT $son,$limit"); 

echo"<tr>
<td><a href='?sayfa=uyeler&sirala=uye_ad'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=uye_ad desc'><img src='images/admin/yukar.bmp'></a></td>
<td><a href='?sayfa=uyeler&sirala=admin'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=admin desc'><img src='images/admin/yukar.bmp'></a></td>
<td><a href='?sayfa=uyeler&sirala=uye_kayit'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=uye_kayit desc'><img src='images/admin/yukar.bmp'></a></td>
<td><a href='?sayfa=uyeler&sirala=login'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=login desc'><img src='images/admin/yukar.bmp'></a></td>
<td><a href='?sayfa=uyeler&sirala=uye_mail'><img src='images/admin/assa.bmp'></a>
    <a href='?sayfa=uyeler&sirala=uye_mail desc'><img src='images/admin/yukar.bmp'></a></td>

<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>"; 
}    
}





 

  while($uye = mysql_fetch_array($uyeler)){ 
$a=$uye['admin'];
echo"
<tr style='background-color:".( ($uye['ban'] == "1") ? '#CCC' : '' )."'><td>
<b>";
if(isset($_POST['ara'])){ echo"".eregi_replace($_POST['ara'] ,$renkdegistir,$uye['uye_ad'])."";}else{ echo"$uye[uye_ad]"; }
echo"
</b></td>
<td><form class='formx' action='?sayfa=uyeler' method='post' >
";

if($uye['admin']== 5){
echo"<img src='images/admin/artip.bmp' >";
}else{
echo"<input type='image' name='arti' value='$uye[uye_id]' src='images/admin/arti.bmp'>"; }

if($uye['admin']== 0){
echo" <img src='images/admin/eksip.bmp' >";
}else{
echo" <input type='image' name='eksi' value='$uye[uye_id]' src='images/admin/eksi.bmp'>"; }

echo"
<input type='hidden' name='var' value='$uye[admin]' ></form>
 <div class='rank$a' >$rank[$a]</div></td>
<td> ".zamangoster($uye['uye_kayit'])."</td>
<td> ".zamangoster($uye['login'])."</td>
<td><a href='?gonder=mail&id=$uye[uye_id]'><img src='images/admin/mail.bmp'></a> ";
if(isset($_POST['ara'])){ echo"".eregi_replace($_POST['ara'] ,$renkdegistir,$uye['uye_mail'])."";}else{ echo"$uye[uye_mail]"; }
echo"</td>
<td width='1%'><form class='formx' method='post' action='?duzenle=uye'><input type='image' src='images/admin/duzen.gif' name='uid' value='$uye[uye_id]' ></form></td>
<td  width='1%'><form class='formx' method='post' action=''><input type='image' src='images/admin/sil.gif' name='sil' value='$uye[uye_id]'></form>  </td>
<td  width='1%'><form class='formx' method='post' action='?sayfa=uyeler'><input type='image' src='images/admin/ban$uye[ban].bmp' name='ban' value='$uye[uye_id]'><input type='hidden' name='bi' value='$uye[ban]' > </form>  </td>";


if($_POST['sil']==$uye['uye_id']){
echo"<tr ><td colspan='7' class='kirmizi'  width='1%'><img src='images/admin/alt.gif'> Silmek icin onaylay�n <form class='formx' method='post' action='?sil=uye'>
<td class='kirmizi'><input type='image' src='images/admin/onay.gif' name='uid' value='$uye[uye_id]'></td></form></td></tr>";

}

  }

  echo"<tr><td colspan='8' width='1%' ><form action='?ekle=uye' method='post' class='formx'>
  isim <input type='text' name='isim' > key <input type='password' name='sifre' > mail :<input type='text' name='mail' >
  <input type='submit' value='kaydet' ></form></td></tr>";
  
 
 echo"<tr><td colspan='8'>";

if(isset($_POST['ara'])){
$ss = mysql_query("SELECT * FROM uyeler  where (uye_ad LIKE '%$_POST[ara]%' || uye_mail LIKE '%$_POST[ara]%') order by $_POST[sirala] $_POST[siralat]  ");
$pages = mysql_num_rows($ss);
}else{
$ss = mysql_query("SELECT * FROM uyeler    "); 
$pages = mysql_num_rows($ss);
}
$sayfasay = ceil($pages / $limit);


if(isset($_POST['ara'])){






echo"<div class='pagesnav'>";


echo"<form class='formy' action='?sayfa=uyeler&sirala=ara&s=".$b."' method='post'>
<input type='hidden' name='ara' value='$_POST[ara]' >
<input type='hidden' name='sirala' value='$_POST[sirala]' >
<input type='hidden' name='siralat' value='$_POST[siralat]' >
";

if ($_GET['s']==1) {
echo"<a id='pasif' href='#' >Geri</a> ";}else{$birGeri=$x-1;
echo"<button class='formy'><a href='?sayfa=$_GET[sayfa]&s=".$b."'>Geri</a></button> ";}
echo"</form>";





for($i=1; $i <= $sayfasay; $i++)
{if ($_GET['s']==$i) {
echo"<form class='formy' action='?sayfa=uyeler&sirala=ara&s=$i' method='post'>
<input type='hidden' name='ara' value='$_POST[ara]' >
<input type='hidden' name='sirala' value='$_POST[sirala]' >
<input type='hidden' name='siralat' value='$_POST[siralat]' >
";
echo"<button class='formy'><a id='hovered'  href='#'>$i</a> </button></form>";continue;}
echo"<form class='formy' action='?sayfa=uyeler&sirala=ara&s=$i' method='post'>
<input type='hidden' name='ara' value='$_POST[ara]' >
<input type='hidden' name='sirala' value='$_POST[sirala]' >
<input type='hidden' name='siralat' value='$_POST[siralat]' >
";
echo"<button class='formy'><a href='?sayfa=$_GET[sayfa]&s=$i'>$i</a></button></form>";}



echo"<form class='formy' action='?sayfa=uyeler&sirala=ara&s=".$ar."' method='post'>
<input type='hidden' name='ara' value='$_POST[ara]' >
<input type='hidden' name='sirala' value='$_POST[sirala]' >
<input type='hidden' name='siralat' value='$_POST[siralat]' >
";
if ($_GET['s']<$sayfasay) {
echo"<button class='formy'><a href='?sayfa=".$_GET['sayfa']."&s=".$ar."'>ileri</a></button>";}else{
echo"<a id='pasif' href='#' >ileri</a>";}
echo"</form>";








if($sayfasay >= $limit){

echo"";
}else{
echo"";}
echo"</div>";




}else{

echo"<div class='pagesnav'>";
if ($_GET['s']==1) {
echo"<a id='pasif' href='#' >Geri</a> ";}else{$birGeri=$x-1;
echo"<a href='?sayfa=$_GET[sayfa]&s=".$b."'>Geri</a> ";}

for($i=1; $i <= $sayfasay; $i++)
{if ($_GET['s']==$i) {
echo"<a id='hovered'  href='#'>$i</a> ";continue;}
echo"<a href='?sayfa=$_GET[sayfa]&s=$i'>$i</a> ";}

if ($_GET['s']<$sayfasay) {
echo"<a href='?sayfa=".$_GET['sayfa']."&s=".$ar."'>ileri</a>";}else{
echo"<a id='pasif' href='#' >ileri</a>";}

if($sayfasay >= $limit){

echo"";
}else{
echo"";}
echo"</div>";
}




 echo" </td></tr>";  
  echo"</table>";
?>