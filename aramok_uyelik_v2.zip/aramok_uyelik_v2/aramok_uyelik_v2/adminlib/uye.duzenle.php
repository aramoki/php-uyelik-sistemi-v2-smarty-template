<?php


$result = mysql_query("SELECT * FROM uyeler where uye_id='$_POST[uid]' "  );        
      
 while($row = mysql_fetch_array($result)){       


echo"<form action='?duzenleok=uye' method='post' >

<table cellspadding='0' cellspacing='0'  width='100%' id='table1'>
		<tr>
		<td class='kimlikb'>Yeni �ifre:</td>
		<td class='kimlikb'><input type='password'  name='sifre1'  class='textbox' style='padding:4px;'></td>
	</tr>
	<tr>
		<td class='kimlikb'>Yeni �ifreyi Tekrar:</td>
		<td class='kimlikb'><input type='password'  name='sifre2'  class='textbox' style='padding:4px; ' '></td>
	</tr>
	
		<tr>
		<td width='10%' class='kimlika' >Ger�ek Ad�n�z:</td>
		<td class='kimlika'><input type='text'  name='ad' value='$row[uye_ad]' class='textbox' style='padding:4px;'  size='45' ></td>
	
	<tr>
		<td width='10%' class='kimlika' >Mail:</td>
		<td class='kimlika'><input type='text'  name='mail' value='$row[uye_mail]' class='textbox' style='padding:4px;'  size='45' ></td>
	</tr>
	<tr>
		<td class='kimlikb'>Bolge:</td>
		<td class='kimlikb'><input type='text'  name='bolge'  value='$row[uye_bolge]' class='textbox' style='padding:4px;' size='45' ></td>
	</tr>
		<tr>
		<td class='kimlikb'>Web:</td>
		<td class='kimlikb'><input type='text'  name='web'  value='$row[uye_web]' class='textbox' style='padding:4px;' size='45' ></td>
	</tr>
	<tr>
		<td class='kimlikb'>Meslek:</td>
		<td class='kimlikb'><input type='text'  name='meslek'  value='$row[uye_meslek]' class='textbox' 
		style='padding:4px;'  size='45' ></td>
	</tr>
	<tr>
		<td class='kimlikb' valign='top' >Bilgi:</td>
		<td class='kimlikb'>
		<textarea  name='bilgi'  class='textbox' style='padding:4px;'  cols='50'  rows='20' >$row[uye_bilgi]</textarea>
		 </td>
	</tr>
	<tr>
		<td class='kimlikb'>&nbsp;</td>
		<td class='kimlikb'><input type='hidden' value='$row[uye_id]' checked name='kid' ><input type='submit' value='Guncelle' class='button' ></td>
	</tr>
	

</form>
";
} 



?>