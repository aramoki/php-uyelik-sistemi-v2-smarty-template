<?php


$sql = mysql_query("DELETE FROM uyeler WHERE uye_id='$_POST[uid]'");

if (!mysql_query($sql,$bag))
  {
  die('Silindi');
  }



