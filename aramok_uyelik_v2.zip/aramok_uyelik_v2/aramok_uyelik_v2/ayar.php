<?php
include"ust.php";

$sql=mysql_query("UPDATE uyeler SET 
uye_bolge='$_POST[bolge]', 
uye_mail='$_POST[mail]' ,
uye_web='$_POST[web]',
uye_ad='$_POST[ad]' ,
uye_meslek='$_POST[meslek]',
uye_bilgi='$_POST[bilgi]'
WHERE uye_id = '$_POST[kid]'
");






if (!mysql_query($sql,$con)){ $smarty->assign('uyeuyari',"Duzenlendi");}



 

$smarty->display('ayar.tpl');


