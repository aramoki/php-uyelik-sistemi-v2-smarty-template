<?php
include"ust.php";

$uyeidp=$_POST['uidp'];
$sifre=$_POST['sifre'];
$sifre1=$_POST['sifre1'];
$sifre2=$_POST['sifre2'];
$osifre=sha1($sifre); 
$msifre=sha1($sifre1); 

if(($sifre1=="") or ($sifre2=="")){ 
$smarty->assign('sifreuyari',"L�tfen Bo� Alanlar� Doldurunuz");
}else{
if($sifre1==$sifre2){
$sorgu = mysql_query("select * from uyeler where  uye_id='$uyeidp' and uye_sifre='$osifre'");
$uyevarmi = mysql_num_rows($sorgu);
if($uyevarmi == 0) {
$smarty->assign('sifreuyari',"Sifrenizi yaanl�� Girdiniz");
} else {
mysql_query("UPDATE uyeler SET uye_sifre='$msifre'
WHERE uye_id = '$uyeidp'
");
$smarty->assign('sifreuyari',"Sifreniz De�i�tirildi");
}
}else{
$smarty->assign('sifreuyari',"Yazd���n�z �ifreler E�it De�il");}
}




$smarty->display('ayarsifre.tpl');


?>