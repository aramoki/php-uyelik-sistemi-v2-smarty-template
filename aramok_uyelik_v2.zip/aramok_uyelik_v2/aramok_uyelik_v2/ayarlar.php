<?php
include"ust.php";


$uu = Array(); 
$result = mysql_query("SELECT * FROM uyeler where uye_id='$_COOKIE[uyeid]' "  );  
while ($uye = mysql_fetch_assoc($result)){
   $uu[] = $uye; 
}

$smarty->assign('row', $uu); 
$smarty->assign('id',"$_COOKIE[uyeid]");


$smarty->display('ayarlar.tpl')







?>