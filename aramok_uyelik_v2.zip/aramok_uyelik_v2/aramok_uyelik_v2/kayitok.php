<?php
include"ust.php";


if($_POST['ad']!=""){
if($_POST['sifre1']!=""){
if($_POST['sifre2']!=""){
if($_POST['mail']!=""){
if($_POST['sifre1']==$_POST['sifre2']){
if($_POST['ad']!=$_POST['sifre1']){


$uyesorgu=mysql_query("Select uye_ad from uyeler where uye_ad='".$_POST['ad']."'");
$mailsorgu = mysql_query("SELECT uye_mail FROM uyeler WHERE uye_mail='".$_POST['mail']."'");  
$uyesayi=mysql_num_rows($uyesorgu); 
$mailsayi=mysql_num_rows($mailsorgu); 
if (!($uyesayi>0)){
if (!($mailsayi>0)){


$sifre=sha1($_POST['sifre1']);



$uyeekle = "INSERT INTO uyeler (uye_id,uye_ad, uye_sifre, uye_mail,uye_kayit,aktif) 
VALUES ('','".$_POST['ad']."', '".$sifre."', '".$_POST['mail']."',now(),0 )";

if (!mysql_query($uyeekle,$bag))
  {
  die('Err�r: ' . mysql_error());
  }else{
  
  

  
$onay = substr(md5(uniqid(rand())), 0, 6);
$yenisifre=sha1($onay);
$onaycek=mysql_query("UPDATE uyeler SET ctrl ='$onay' where uye_ad='$_POST[ad]' and uye_mail='$_POST[mail]'");
$mesaj =" aktivasyon icin onay kodunuz : -$onay-  - aras�ndakileri dinkkate al�nz";
$headers .= "From: siteadi ". "sitemail\r\n";
$headers .= "Reply-To: sitemail\r\n";
$headers .= "Return-path: mohorame@gmail.com\r\n";
$headers .= "Content-Type: text/html; charset=iso-8859-9\n"; /*karakter seti, t�rk�e i�in -9 kulland�k*/  
mail($_POST['mail'],"siteadi - $_POST[ad] kullanicisi aktivasyon maili",$mesaj,$headers); /* ve maili g�nderiyoruz */  

$gmail = substr($uyes['uye_mail'], 0, 8);
$smarty->assign('bildir',"
Sonunda ba�ard�n<br>uyesin lan art�k sevin bence.
  <br>bunlar� akl�nda tut bak unutma: kimseyede g�sterme s�yleme!<br><br>
  <b>kullanici adin:</b>$_POST[ad]<br>
  <b>Sifren:</b>$_POST[sifre1]<br>
  <b>mail adresin:</b>$_POST[mail]<br>
  <br>aktivasyon maili $_POST[mail] adresine gonderildi 
  <form action='activation.php' method='post' >
  <input type='hidden' name='ad' value='$_POST[ad]' ><input type='text' name='kod' ><input type='submit' value='aktivasyon'></form>");


  
  }


 
 
}else{$smarty->assign('bildir',"sectigin mail var");}
}else{$smarty->assign('bildir',"sectigin kullanici adi var");}
}else{$smarty->assign('bildir',"kullan�c� ad�n �ifrene e�it olamaz");}
}else{$smarty->assign('bildir',"sifreler esit de�il be");}
}else{$smarty->assign('bildir',"mail adresini yamad�n�z");}
}else{$smarty->assign('bildir',"sifre tekrar�n� girmediniz");}
}else{$smarty->assign('bildir',"sifreyi girmediniz");}
}else{$smarty->assign('bildir',"adinizi girmediniz");}

$smarty->display('kayitok.tpl'); 
?>
