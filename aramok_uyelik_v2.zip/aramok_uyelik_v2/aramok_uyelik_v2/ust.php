<?php
require "baglanti.php";

header("Content-Type: text/html; charset=ISO-8859-9");
@setlocale (LC_TIME, "turkish" );

require_once('Smarty.class.php');

$smarty = new Smarty();
$smarty->template_dir = 'template/simple';
$smarty->compile_dir  = 'templates_c';
$smarty->config_dir   = 'configs';
$smarty->cache_dir    = 'cache';


function zamangoster($zamandamga){
$year=strval(substr($zamandamga,0,4)); 
$month=strval(substr($zamandamga,5,2)); 
$day=strval(substr($zamandamga,8,2)); 
$hour=strval(substr($zamandamga,10,3)); 
$min=strval(substr($zamandamga,14,2)); 
return strftime("%d %B %Y %H:%M", mktime($hour,$min,0,$month,$day,$year)); 
}





$uyesonuc = mysql_query("SELECT * FROM uyeler  WHERE uye_id = '$_COOKIE[uyeid]'  and uye_ad ='$_COOKIE[uyead]' and ban='0' "  );            
while($uye = mysql_fetch_array($uyesonuc)){ 
	$smarty->assign('id',"$uye[uye_id]");
	$smarty->assign('ad',"$uye[uye_ad]");
	$smarty->assign('mail',"$uye[uye_mail]");
	$smarty->assign('kayit',zamangoster($uye['uye_kayit']));
 if($uye['avatar']==""){
	$smarty->assign('avatar',"noav.gif");
}else{
	$smarty->assign('avatar',$uye['avatar']);}


$rank=array("user1","user2","Moderator","Editor","coAdmin","Admin");
$a=$uye['admin'];
$smarty->assign('admin',$rank[$a]);
$smarty->assign('rank',$uye['admin']);
}


if($sec = 0){
setcookie("uyeid", "", time() - 7200);
setcookie("uyead", "", time() - 7200);
setcookie("uyemail", "", time() - 7200);
}





//** un-comment the following line to show the debug console
//$smarty->debugging = true;

$smarty->display('ust.tpl');
?>