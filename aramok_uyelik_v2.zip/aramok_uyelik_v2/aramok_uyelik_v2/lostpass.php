<?
include"ust.php";



$uyesorgu=mysql_query("Select * from uyeler where uye_ad='$_POST[moa]' or uye_mail='$_POST[moa]'");
$uyesayi=mysql_num_rows($uyesorgu); 

if (!($uyesayi>0)){
$smarty->assign('bildir',"ad yada mail bulunamadi");
}else{

$onay = substr(md5(uniqid(rand())), 0, 6);
$yenisifre=sha1($onay);
$onaycek=mysql_query("UPDATE uyeler SET uye_sifre ='$yenisifre' where uye_ad='$_POST[moa]' or uye_mail='$_POST[moa]'");
while($uyes=mysql_fetch_assoc($uyesorgu)){


$mesaj ="$uyes[uye_mail] mail adresi ile $uyes[uye_ad] isimli kullanicinin sifremi unuttum gonderisi icin yeni sifre<br>
-$onay-  - aras�ndakileri dinkkate al�nz";
$headers .= "From: siteadi ". "sitemail\r\n";
$headers .= "Reply-To: sitemail\r\n";
$headers .= "Return-path: mohorame@gmail.com\r\n";
$headers .= "Content-Type: text/html; charset=iso-8859-9\n"; /*karakter seti, t�rk�e i�in -9 kulland�k*/  
mail($uyes['uye_mail'],"siteadi - $uyes[uye_ad] kullanicisi sifremi unuttum maili",$mesaj,$headers); /* ve maili g�nderiyoruz */  

$gmail = substr($uyes['uye_mail'], 0, 8);
$smarty->assign('bildir',"mail $gmail... adresine gonderildi ");
}


}



$smarty->display('lostpass.tpl'); 
?>