<?php

require "baglanti.php";
require_once('Smarty.class.php');

$smarty = new Smarty();


$smarty->template_dir = 'template/simple';
$smarty->compile_dir  = 'templates_c';
$smarty->config_dir   = 'configs';
$smarty->cache_dir    = 'cache';

#$smarty->assign('id',"$_COOKIE[uyeid]");
#$smarty->assign('ad',"$_COOKIE[uyead]");
#$smarty->assign('mail',"$_COOKIE[uyemail]");







//** un-comment the following line to show the debug console
//$smarty->debugging = true;

$smarty->display('kayit.tpl');
?>