<?
include"ust.php";



$smarty->display('sifremiunuttum.tpl'); 
?>